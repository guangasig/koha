# [KOHA](https://koha-community.org)  Sistema integrado de gestión de bibliotecas
![Badge en Desarollo](https://img.shields.io/badge/STATUS-EN%20DESAROLLO-green)

### Instalación y Personalización de Koha 

## Instalación
* [Instalación en Debian](https://manuelguangasig.com)
* [Instalación en Ubuntu](https://manuelguangasig.com)
* [Soluciones a instalaciones en distribuciones Linux basada en Debian](https://manuelguangasig.com)

## Personalización
* [Línea gráfica CREATIVITY IN-SE](http://167.71.22.115:8000)
* [Línea gráfica ISTE]([http://167.71.22.115:8000/](https://manuelguangasig.com))