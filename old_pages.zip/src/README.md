# [ISTE](https://iste.edu.ec)
## Línea gráfica de la institución

### Colores

| Descripción | Color | Código | 
| --- | --- | --- |
| Texto | ![#001d7e](https://via.placeholder.com/15/001d7e/000000?text=+) | `#001d7e` |
| Texto para fechas | ![#8a8a91](https://via.placeholder.com/15/8a8a91/000000?text=+) | `#8a8a91` |
| Texto para Hashtag | ![#525252](https://via.placeholder.com/15/525252/000000?text=+) | `#525252` |
| Background  | ![#001d7e](https://via.placeholder.com/15/001d7e/000000?text=+) | `#001d7e` |
| Background cajas de texto | ![#d6e6ff](https://via.placeholder.com/15/d6e6ff/000000?text=+) | `#d6e6ff` |
| Background hover en el menu | ![#d6e6ffcf](https://via.placeholder.com/15/D6E6FFCF/000000?text=+) | `#d6e6ffcf` |
 
### Iconos e Imagenes

| Descripción | Ver | Dimensiones | 
| --- | --- | --- |
| Favicon | ![Ver](https://iste.edu.ec/wp-content/uploads/2021/07/Logo-ISTE.svg) |  |
| Logo | ![Ver](https://iste.edu.ec/wp-content/uploads/2021/07/Logo-Tipo.webp) |  |

### Fuentes

| Family | Link |
| --- | --- |
| Swap | https://fonts.googleapis.com/css2?family=Raleway&display=swap |
| Exo 2 | https://fonts.googleapis.com/css?family=Exo 2 |
